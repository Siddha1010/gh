import java.util.ArrayList;
import java.util.List;

// Command Pattern
interface Command {
    void execute();
}

class StartCookingCommand implements Command {
    private Microwave microwave;

    public StartCookingCommand(Microwave microwave) {
        this.microwave = microwave;
    }

    @Override
    public void execute() {
        microwave.startCooking();
    }
}

class PauseCookingCommand implements Command {
    private Microwave microwave;

    public PauseCookingCommand(Microwave microwave) {
        this.microwave = microwave;
    }

    @Override
    public void execute() {
        microwave.pauseCooking();
    }
}

class ResumeCookingCommand implements Command {
    private Microwave microwave;

    public ResumeCookingCommand(Microwave microwave) {
        this.microwave = microwave;
    }

    @Override
    public void execute() {
        microwave.resumeCooking();
    }
}

class FinishCookingCommand implements Command {
    private Microwave microwave;

    public FinishCookingCommand(Microwave microwave) {
        this.microwave = microwave;
    }

    @Override
    public void execute() {
        microwave.finishCooking();
    }
}

// State Pattern
interface MicrowaveState {
    void startCooking();
    void pauseCooking();
    void resumeCooking();
    void finishCooking();
}

class GrillingState implements MicrowaveState {
    private Microwave microwave;

    public GrillingState(Microwave microwave) {
        this.microwave = microwave;
    }

    @Override
    public void startCooking() {
        System.out.println("Grilling started.");
        // Your grilling logic here
        microwave.notifyObservers();
    }

    @Override
    public void pauseCooking() {
        System.out.println("Grilling paused.");
        // Your pause logic here
        microwave.notifyObservers();
    }

    @Override
    public void resumeCooking() {
        System.out.println("Grilling resumed.");
        // Your resume logic here
        microwave.notifyObservers();
    }

    @Override
    public void finishCooking() {
        System.out.println("Grilling finished.");
        // Your finish logic here
        microwave.setState(new IdleState(microwave));
        microwave.notifyObservers();
    }
}

class CookState implements MicrowaveState {
    private Microwave microwave;

    public CookState(Microwave microwave) {
        this.microwave = microwave;
    }

    @Override
    public void startCooking() {
        System.out.println("Cooking started.");
        // Your cooking logic here
        microwave.notifyObservers();
    }

    @Override
    public void pauseCooking() {
        System.out.println("Cooking paused.");
        // Your pause logic here
        microwave.notifyObservers();
    }

    @Override
    public void resumeCooking() {
        System.out.println("Cooking resumed.");
        // Your resume logic here
        microwave.notifyObservers();
    }

    @Override
    public void finishCooking() {
        System.out.println("Cooking finished.");
        // Your finish logic here
        microwave.setState(new IdleState(microwave));
        microwave.notifyObservers();
    }
}

class RoastState implements MicrowaveState {
    private Microwave microwave;

    public RoastState(Microwave microwave) {
        this.microwave = microwave;
    }

    @Override
    public void startCooking() {
        System.out.println("Roasting started.");
        // Your roasting logic here
        microwave.notifyObservers();
    }

    @Override
    public void pauseCooking() {
        System.out.println("Roasting paused.");
        // Your pause logic here
        microwave.notifyObservers();
    }

    @Override
    public void resumeCooking() {
        System.out.println("Roasting resumed.");
        // Your resume logic here
        microwave.notifyObservers();
    }

    @override
    public void finishCooking() {
        System.out.println("Roasting finished.");
        // Your finish logic here
        microwave.setState(new IdleState(microwave));
        microwave.notifyObservers();
    }
}

class BakeState implements MicrowaveState {
    private Microwave microwave;

    public BakeState(Microwave microwave) {
        this.microwave = microwave;
    }

    @Override
    public void startCooking() {
        System.out.println("Baking started.");
        // Your baking logic here
        microwave.notifyObservers();
    }

    @Override
    public void pauseCooking() {
        System.out.println("Baking paused.");
        // Your pause logic here
        microwave.notifyObservers();
    }

    @Override
    public void resumeCooking() {
        System.out.println("Baking resumed.");
        // Your resume logic here
        microwave.notifyObservers();
    }

    @Override
    public void finishCooking() {
        System.out.println("Baking finished.");
        // Your finish logic here
        microwave.setState(new IdleState(microwave));
        microwave.notifyObservers();
    }
}

class IdleState implements MicrowaveState {
    private Microwave microwave;

    public IdleState(Microwave microwave) {
        this.microwave = microwave;
    }

    @Override
    public void startCooking() {
        System.out.println("Microwave is now cooking.");
        microwave.setState(new GrillingState(microwave));
        microwave.notifyObservers();
    }

    @Override
    public void pauseCooking() {
        System.out.println("Microwave is idle. Nothing to pause.");
    }

    @Override
    public void resumeCooking() {
        System.out.println("Microwave is idle. Nothing to resume.");
    }

    @Override
    public void finishCooking() {
        System.out.println("Microwave is already idle.");
    }
}

// Observer Pattern
interface MicrowaveObserver {
    void update();
}

class CookingProgressObserver implements MicrowaveObserver {
    private Microwave microwave;

    public CookingProgressObserver(Microwave microwave) {
        this.microwave = microwave;
    }

    @Override
    public void update() {
        System.out.println("Cooking progress updated.");
        // Your progress update logic here
    }
}

class TemperatureObserver implements MicrowaveObserver {
    private Microwave microwave;

    public TemperatureObserver(Microwave microwave) {
        this.microwave = microwave;
    }

    @Override
    public void update() {
        System.out.println("Temperature updated.");
        // Your temperature update logic here
    }
}

class TimeObserver implements MicrowaveObserver {
    private Microwave microwave;

    public TimeObserver(Microwave microwave) {
        this.microwave = microwave;
    }

    @Override
    public void update() {
        System.out.println("Time updated.");
        // Your time update logic here
    }
}

public class MicrowaveApp {
    public static void main(String[] args) {
        Microwave microwave = new Microwave();
        microwave.addObserver(new CookingProgressObserver(microwave));
        microwave.addObserver(new TemperatureObserver(microwave));
        microwave.addObserver(new TimeObserver(microwave));
        microwave.setState(new IdleState(microwave));

        Command startCommand = new StartCookingCommand(microwave);
        Command pauseCommand = new PauseCookingCommand(microwave);
        Command resumeCommand = new ResumeCookingCommand(microwave);
        Command finishCommand = new FinishCookingCommand(microwave);

        startCommand.execute();
        pauseCommand.execute();
        resumeCommand.execute();
        finishCommand.execute();
    }
}

