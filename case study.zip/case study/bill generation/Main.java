import java.util.Scanner;

interface CreditCardBill {
    void generateBill(int month, int numberOfTransactions);
}

class SilverCardBill implements CreditCardBill {
    @Override
    public void generateBill(int month, int numberOfTransactions) {
        double monthlyAmount = 1000.0;

        if (month == 2) {
            monthlyAmount *= 1.1;
        } else if (month == 6 || month == 12) {
            monthlyAmount *= 0.9;
        }

        // Apply discounts based on the number of transactions
        if (numberOfTransactions > 5) {
            monthlyAmount -= 50.0;
        }

        System.out.println("Generating Silver Card Bill for Month " + month + " with " + numberOfTransactions + " transactions: Rs." + monthlyAmount);
    }
}

class GoldCardBill implements CreditCardBill {
    @Override
    public void generateBill(int month, int numberOfTransactions) {
        double monthlyAmount = 1500.0;

        if (month == 4) {
            monthlyAmount *= 1.2;
        } else if (month == 8 || month == 11) {
            monthlyAmount *= 0.85;
        }

        // Apply discounts based on the number of transactions
        if (numberOfTransactions > 10) {
            monthlyAmount -= 100.0;
        }

        System.out.println("Generating Gold Card Bill for Month " + month + " with " + numberOfTransactions + " transactions: Rs." + monthlyAmount);
    }
}

class PlatinumCardBill implements CreditCardBill {
    @Override
    public void generateBill(int month, int numberOfTransactions) {
        double monthlyAmount = 2000.0;

        if (month == 3) {
            monthlyAmount *= 1.15;
        } else if (month == 7 || month == 9) {
            monthlyAmount *= 0.95;
        }

        // Apply discounts based on the number of transactions
        if (numberOfTransactions > 15) {
            monthlyAmount -= 150.0;
        }

        System.out.println("Generating Platinum Card Bill for Month " + month + " with " + numberOfTransactions + " transactions: Rs." + monthlyAmount);
    }
}

public class Main {
    public static void main(String[] args) {
        BillGeneratorFactory factory = new BillGeneratorFactory();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Enter card type (Silver/Gold/Platinum) or 'exit' to quit:");
            String cardType = scanner.nextLine();

            if (cardType.equalsIgnoreCase("exit")) {
                break;
            }

            System.out.println("Enter month (1-12):");
            int month = scanner.nextInt();
            scanner.nextLine();

            System.out.println("Enter the number of transactions you did for month " + month + ":");
            int numberOfTransactions = scanner.nextInt();
            scanner.nextLine();

            CreditCardBill bill = factory.createBill(cardType);
            bill.generateBill(month, numberOfTransactions);
        }

        System.out.println("Exiting...");
    }
}

