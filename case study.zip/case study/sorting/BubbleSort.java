// Bubble Sort Implementation
public class BubbleSort implements SortingAlgorithmInterface {
    @Override
    public void sort(int[] array) {
        // Implement Bubble Sort logic here
    }
}

