// QuickSort Implementation
public class QuickSort implements SortingAlgorithmInterface {
    @Override
    public void sort(int[] array) {
        // Implement QuickSort logic here
    }
}

