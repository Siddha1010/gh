public class Server {
    public int[] handleClientRequest(SortingAlgorithmInterface selectedAlgorithm, int[] data) {
        SortingContext sortingContext = new SortingContext();
        sortingContext.setSortingAlgorithm(selectedAlgorithm);
        
        // Perform sorting based on the selected algorithm
        sortingContext.performSort(data);
        
        // Return the sorted array
        return data;
    }
}

