// Sorting Algorithm Interface
public interface SortingAlgorithmInterface {
    void sort(int[] array);
}
     
