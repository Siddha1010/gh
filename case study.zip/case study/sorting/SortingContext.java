// Sorting Context (Data Mining Agent)
public class SortingContext {
    private SortingAlgorithmInterface sortingAlgorithm;

    public void setSortingAlgorithm(SortingAlgorithmInterface algorithm) {
        this.sortingAlgorithm = algorithm;
    }

    public void performSort(int[] array) {
        sortingAlgorithm.sort(array);
    }
}

