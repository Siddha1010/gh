package com.portal;

public interface Observer {
	 void update(String message);
}
