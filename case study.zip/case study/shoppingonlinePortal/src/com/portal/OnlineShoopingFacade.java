package com.portal;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class OnlineShoopingFacade {
	private InventorySystem inventorySystem;
    private OrderProcessingSystem orderProcessingSystem;
    private PaymentSystem paymentSystem;
    private Subject orderSubject;
    private Subject paymentSubject;

    OnlineShoppingFacade() {
        inventorySystem = new InventorySystem();
        orderProcessingSystem = new OrderProcessingSystem();
        paymentSystem = new PaymentSystem();
        orderSubject = new Subject();
        paymentSubject = new Subject();
        orderSubject.addObserver(new OrderTracker());
        paymentSubject.addObserver(new PaymentNotifier());
    }
    void placeOrder(String product, String paymentMethod) {
        if (inventorySystem.isAvailable(product)) {
            orderProcessingSystem.placeOrder(product);
            orderSubject.notifyObservers("Order placed successfully for " + product);
            paymentSystem.processPayment(paymentMethod);
            paymentSubject.notifyObservers("Payment processed using " + paymentMethod);
        } else {
            orderSubject.notifyObservers("Product " + product + " is out of stock");
        }
    }
}
