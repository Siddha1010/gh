package com.portal;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Subject {
	private List<Observer> observers = new ArrayList<>();

    void addObserver(Observer observer) {
        observers.add(observer);
    }

    void notifyObservers(String message) {
        for (Observer observer : observers) {
            observer.update(message);
        }
    }
}
