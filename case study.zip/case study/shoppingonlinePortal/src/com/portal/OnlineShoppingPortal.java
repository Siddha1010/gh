package com.portal;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class OnlineShoppingPortal {
	 public static void main(String[] args) {
	  //      OnlineShoppingFacade shoppingFacade = new OnlineShoppingFacade();
	        Scanner scanner = new Scanner(System.in);
	        boolean continueShopping = true;

	        while (continueShopping) {
	            System.out.println("Menu:");
	            System.out.println("1. Place Order");
	            System.out.println("2. Exit");
	            System.out.print("Enter your choice: ");
	            int choice = scanner.nextInt();
	            scanner.nextLine(); // Consume newline
	            switch (choice) {
                case 1:
                    System.out.print("Enter the product to order: ");
                    String product = scanner.nextLine();
                    System.out.print("Enter payment method (cash/debit/credit): ");
                    String paymentMethod = scanner.nextLine();
             //       shoppingFacade.placeOrder(product, paymentMethod);
                    break;
                case 2:
                    continueShopping = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        System.out.println("Thank you for shopping with us!");
        scanner.close();
    }
	        }
