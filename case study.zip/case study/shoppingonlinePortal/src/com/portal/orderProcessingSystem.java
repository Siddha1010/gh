package com.portal;

public class orderProcessingSystem {
	  void placeOrder(String product) {
	        // Place order logic
	    }
}
