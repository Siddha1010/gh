package com.portal;

public class PaymentSystem {
	void processPayment(String paymentMethod) {
        // Payment processing logic
    }
}
