import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;
import java.awt.Graphics;

interface Shape {
    void draw(Graphics g);
}

class Rectangle implements Shape {
    @Override
    public void draw(Graphics g) {
        g.drawRect(50, 50, 100, 80);
    }
}

class Circle implements Shape {
    @Override
    public void draw(Graphics g) {
        g.drawOval(200, 50, 80, 80);
    }
}

class Triangle implements Shape {
    @Override
    public void draw(Graphics g) {
        int[] xPoints = {250, 200, 300};
        int[] yPoints = {50, 130, 130};
        g.drawPolygon(xPoints, yPoints, 3);
    }
}

class Square implements Shape {
    @Override
    public void draw(Graphics g) {
        g.drawRect(350, 50, 80, 80);
    }
}

class Cube implements Shape {
    @Override
    public void draw(Graphics g) {
        g.drawRect(750, 50, 80, 80);
        g.drawRect(700, 90, 80, 80);
        g.drawLine(750, 50, 700, 90);
        g.drawLine(830, 50, 780, 90);
        g.drawLine(750, 130, 700, 170);
        g.drawLine(830, 130, 780, 170);
    }
}

abstract class ShapeDecorator implements Shape {
    protected Shape decoratedShape;

    public ShapeDecorator(Shape decoratedShape) {
        this.decoratedShape = decoratedShape;
    }

    @Override
    public void draw(Graphics g) {
        decoratedShape.draw(g);
    }
}

class ColourShapeDecorator extends ShapeDecorator {
    private Color color;

    public ColourShapeDecorator(Shape decoratedShape, Color color) {
        super(decoratedShape);
        this.color = color;
    }

    @Override
    public void draw(Graphics g) {
        super.draw(g);
        g.setColor(color);
        decoratedShape.draw(g);
    }
}

class AddShapeDecorator implements Shape {
    private Shape decoratedShape;
    private Shape addedShape;

    public AddShapeDecorator(Shape decoratedShape, Shape addedShape) {
        this.decoratedShape = decoratedShape;
        this.addedShape = addedShape;
    }

    @Override
    public void draw(Graphics g) {
        decoratedShape.draw(g);
        addedShape.draw(g);
    }
}

class DrawingCanvas extends JPanel {
    private Shape shape;
    private Color fillColor;

    public void setShape(Shape shape) {
        this.shape = shape;
        repaint();
    }

    public void setFillColor(Color fillColor) {
        this.fillColor = fillColor;
        repaint();
    }

    public Shape getShape() {
        return shape;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (shape != null) {
            if (fillColor != null) {
                g.setColor(fillColor);
                shape.draw(g);
            } else {
                shape.draw(g);
            }
        }
    }
}

class IncreaseSizeDecorator extends ShapeDecorator {
    public IncreaseSizeDecorator(Shape decoratedShape) {
        super(decoratedShape);
    }

    @Override
    public void draw(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.scale(1.2, 1.2);
        super.draw(g2d);
    }
}

class DecreaseSizeDecorator extends ShapeDecorator {
    public DecreaseSizeDecorator(Shape decoratedShape) {
        super(decoratedShape);
    }

    @Override
    public void draw(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.scale(0.8, 0.8);
        super.draw(g2d);
    }
}

class PaintingApp {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Decorator Pattern - Painting App");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 200);

        DrawingCanvas canvas = new DrawingCanvas();

        JButton drawShapesButton = new JButton("Draw Shapes");
        drawShapesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String[] options = {"Rectangle", "Circle", "Triangle", "Square", "Cube"};
                String selectedShape = (String) JOptionPane.showInputDialog(
                        frame,
                        "Choose a shape to draw:",
                        "Select Shape",
                        JOptionPane.QUESTION_MESSAGE,
                        null,
                        options,
                        options[0]);

                if (selectedShape != null) {
                    switch (selectedShape) {
                        case "Rectangle":
                            canvas.setShape(new Rectangle());
                            break;
                        case "Circle":
                            canvas.setShape(new Circle());
                            break;
                        case "Triangle":
                            canvas.setShape(new Triangle());
                            break;
                        case "Square":
                            canvas.setShape(new Square());
                            break;
                        case "Cube":
                            canvas.setShape(new Cube());
                            break;
                    }
                }
            }
        });

        JButton modifyShapeButton = new JButton("Modify Shape");
        modifyShapeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String[] options = {"Rectangle", "Circle", "Triangle", "Square", "Cube"};
                String selectedShape = (String) JOptionPane.showInputDialog(
                        frame,
                        "Choose a shape to modify with:",
                        "Select Shape",
                        JOptionPane.QUESTION_MESSAGE,
                        null,
                        options,
                        options[0]);

                if (selectedShape != null) {
                    Shape currentShape = canvas.getShape();
                    Shape modifiedShape = null;

                    switch (selectedShape) {
                        case "Rectangle":
                            modifiedShape = new Rectangle();
                            break;
                        case "Circle":
                            modifiedShape = new Circle();
                            break;
                        case "Triangle":
                            modifiedShape = new Triangle();
                            break;
                        case "Square":
                            modifiedShape = new Square();
                            break;
                        case "Cube":
                            modifiedShape = new Cube();
                            break;
                    }

                    if (modifiedShape != null) {
                        String[] colorOptions = {"None", "Red", "Green", "Blue", "Yellow"};
                        String selectedColor = (String) JOptionPane.showInputDialog(
                                frame,
                                "Choose a fill color:",
                                "Select Color",
                                JOptionPane.QUESTION_MESSAGE,
                                null,
                                colorOptions,
                                colorOptions[0]);

                        Color fillColor = null;
                        if (selectedColor != null && !selectedColor.equals("None")) {
                            switch (selectedColor) {
                                case "Red":
                                    fillColor = Color.RED;
                                    break;
                                case "Green":
                                    fillColor = Color.GREEN;
                                    break;
                                case "Blue":
                                    fillColor = Color.BLUE;
                                    break;
                                case "Yellow":
                                    fillColor = Color.YELLOW;
                                    break;
                            }
                        }

                        canvas.setFillColor(fillColor);
                        canvas.setShape(new AddShapeDecorator(currentShape, modifiedShape));
                    }
                }
            }
        });

        JButton increaseSizeButton = new JButton("Increase Size");
        increaseSizeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Shape currentShape = canvas.getShape();
                if (currentShape != null) {
                    canvas.setShape(new IncreaseSizeDecorator(currentShape));
                }
            }
        });

        JButton decreaseSizeButton = new JButton("Decrease Size");
        decreaseSizeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Shape currentShape = canvas.getShape();
                if (currentShape != null) {
                    canvas.setShape(new DecreaseSizeDecorator(currentShape));
                }
            }
        });

        JButton clearButton = new JButton("Clear");
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                canvas.setShape(null);
                canvas.setFillColor(null);
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(drawShapesButton);
        buttonPanel.add(modifyShapeButton);
        buttonPanel.add(increaseSizeButton);
        buttonPanel.add(decreaseSizeButton);
        buttonPanel.add(clearButton);

        frame.setLayout(new BorderLayout());
        frame.add(canvas, BorderLayout.CENTER);
        frame.add(buttonPanel, BorderLayout.SOUTH);

        frame.setVisible(true);
    }
}
