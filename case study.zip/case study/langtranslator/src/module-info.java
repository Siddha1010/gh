/**
 * 
 */
/**
 * 
 */
module langtranslator {
}