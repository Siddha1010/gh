package langtranslator;

public class EnglishTranslator {

	public String translateToEnglish(String text) {
        return text;
    }
}