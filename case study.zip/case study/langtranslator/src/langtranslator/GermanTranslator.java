package langtranslator;

public class GermanTranslator {

	
	public String translateToGerman(String text) {
    
        switch (text) {
            case "Hello World":
                return "Hallo Welt";
            case "How are you?":
                return "Wie geht es Ihnen?";
            case "Goodbye":
                return "Auf Wiedersehen";
           
            default:
                return "Translation not available for: " + text;
        }
    }
}