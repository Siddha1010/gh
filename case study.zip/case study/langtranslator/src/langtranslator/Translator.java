package langtranslator;

public interface Translator {
	
	
	String translate(String text);

}