package langtranslator;

public class EnglishToSpanishAdapter implements Translator {
	
	private SpanishTranslator spanishTranslator;

    public EnglishToSpanishAdapter() {
        this.spanishTranslator = new SpanishTranslator();
    }

    @Override
    public String translate(String text) {
        return spanishTranslator.translateToSpanish(text);
    }

}