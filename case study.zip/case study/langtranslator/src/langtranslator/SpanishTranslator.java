package langtranslator;

public class SpanishTranslator {
	
	public String translateToSpanish(String text) {
        
        switch (text) {
            case "Hello World":
                return "Hola Mundo";
            case "How are you?":
                return "¿Cómo estás?";
            case "Goodbye":
                return "Adiós";
           
            default:
                return "Translation not available for: " + text;
        }
    }
}