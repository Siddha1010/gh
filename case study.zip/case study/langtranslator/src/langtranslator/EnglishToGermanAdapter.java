package langtranslator;

public class EnglishToGermanAdapter implements Translator{
	
	
	private GermanTranslator germanTranslator;

    public EnglishToGermanAdapter() {
        this.germanTranslator = new GermanTranslator();
    }

    @Override
    public String translate(String text) {
        return germanTranslator.translateToGerman(text);
    }

}