package langtranslator;

public class Main {

	public static void main(String[] args) {
		   
	        Translator englishToSpanishTranslator = new EnglishToSpanishAdapter();
	        Translator englishToGermanTranslator = new EnglishToGermanAdapter();

	        java.util.Scanner sc = new java.util.Scanner(System.in);
	        System.out.print("Enter text for translation: ");
	        String textToTranslate = sc.nextLine();
	        sc.close();
	        
	        
	        String translatedTextInSpanish = englishToSpanishTranslator.translate(textToTranslate);
	        String translatedTextInGerman = englishToGermanTranslator.translate(textToTranslate);
	        
	        
	        System.out.println("Translated text in Spanish: " + translatedTextInSpanish);
	        System.out.println("Translated text in German: " + translatedTextInGerman);
	    }
	}

