import java.util.Scanner;

//Receiver (Media Player)
interface MediaPlayer {
    void play();
    void pause();
    void stop();
    void openMedia(String mediaFile);
    void editMedia();
    void setCurrentState(PlayerState state);
}

class AudioPlayer implements MediaPlayer {
    private String currentMedia;
    private PlayerState currentState; // Add a field to store the current state

    @Override
    public void play() {
        // Implementation to start playing audio
        System.out.println("Playing audio: " + currentMedia);
        currentState = new PlayingState(this);
    }

    @Override
    public void pause() {
        // Implementation to pause audio
        System.out.println("Pausing audio");
        currentState = new PausedState(this);
    }

    @Override
    public void stop() {
        // Implementation to stop audio
        System.out.println("Stopping audio");
        currentState = new StoppedState(this);
    }

    @Override
    public void openMedia(String mediaFile) {
        // Implementation to open a specific audio file
        currentMedia = mediaFile;
        System.out.println("Opening audio: " + mediaFile);
        currentState = new StoppedState(this);
    }

    @Override
    public void editMedia() {
        // Implementation to edit audio (if supported)
        System.out.println("Editing audio");
        currentState = new EditingState(this);
    }

    @Override
    public void setCurrentState(PlayerState state) {
        this.currentState = state;
    }
}

class VideoPlayer implements MediaPlayer {
    private String currentMedia;
    private PlayerState currentState; // Add a field to store the current state

    @Override
    public void play() {
        // Implementation to start playing video
        System.out.println("Playing video: " + currentMedia);
        currentState = new PlayingState(this);
    }

    @Override
    public void pause() {
        // Implementation to pause video
        System.out.println("Pausing video");
        currentState = new PausedState(this);
    }

    @Override
    public void stop() {
        // Implementation to stop video
        System.out.println("Stopping video");
        currentState = new StoppedState(this);
    }

    @Override
    public void openMedia(String mediaFile) {
        // Implementation to open a specific video file
        currentMedia = mediaFile;
        System.out.println("Opening video: " + mediaFile);
        currentState = new StoppedState(this);
    }

    @Override
    public void editMedia() {
        // Implementation to edit video (if supported)
        System.out.println("Editing video");
        currentState = new EditingState(this);
    }

    @Override
    public void setCurrentState(PlayerState state) {
        this.currentState = state;
    }
}

// States
interface PlayerState {
    void play();
    void pause();
    void stop();
    void edit();
}

class PlayingState implements PlayerState {
    private MediaPlayer mediaPlayer;

    public PlayingState(MediaPlayer mediaPlayer) {
        this.mediaPlayer = mediaPlayer;
    }

    @Override
    public void play() {
        // Already playing, do nothing
    }

    @Override
    public void pause() {
        // Implement pausing
        mediaPlayer.pause();
    }

    @Override
    public void stop() {
        // Implement stopping
        mediaPlayer.stop();
    }

    @Override
    public void edit() {
        // Implement editing behavior
        mediaPlayer.editMedia();
    }
}

class PausedState implements PlayerState {
    private MediaPlayer mediaPlayer;

    public PausedState(MediaPlayer mediaPlayer) {
        this.mediaPlayer = mediaPlayer;
    }

    @Override
    public void play() {
        // Resume playback
        mediaPlayer.play();
    }

    @Override
    public void pause() {
        // Already paused, do nothing
    }

    @Override
    public void stop() {
        // Implement stopping
        mediaPlayer.stop();
    }

    @Override
    public void edit() {
        // Implement editing behavior
        mediaPlayer.editMedia();
    }
}

class StoppedState implements PlayerState {
    private MediaPlayer mediaPlayer;

    public StoppedState(MediaPlayer mediaPlayer) {
        this.mediaPlayer = mediaPlayer;
    }

    @Override
    public void play() {
        // Start playback from the beginning
        mediaPlayer.play();
    }

    @Override
    public void pause() {
        // Implement pausing
        mediaPlayer.pause();
    }

    @Override
    public void stop() {
        // Already stopped, do nothing
    }

    @Override
    public void edit() {
        // Implement editing behavior
        mediaPlayer.editMedia();
    }
}

class EditingState implements PlayerState {
    private MediaPlayer mediaPlayer;

    public EditingState(MediaPlayer mediaPlayer) {
        this.mediaPlayer = mediaPlayer;
    }

    @Override
    public void play() {
        // Cannot play while editing
    }

    @Override
    public void pause() {
        // Implement pausing
        mediaPlayer.pause();
    }

    @Override
    public void stop() {
        // Implement stopping
        mediaPlayer.stop();
    }

    @Override
    public void edit() {
        // Already editing, do nothing
    }
}

// Commands
interface Command {
    void execute();
}

class PlayCommand implements Command {
    private MediaPlayer mediaPlayer;

    public PlayCommand(MediaPlayer mediaPlayer) {
        this.mediaPlayer = mediaPlayer;
    }

    @Override
    public void execute() {
        mediaPlayer.play();
    }
}

class PauseCommand implements Command {
    private MediaPlayer mediaPlayer;

    public PauseCommand(MediaPlayer mediaPlayer) {
        this.mediaPlayer = mediaPlayer;
    }

    @Override
    public void execute() {
        mediaPlayer.pause();
    }
}

class StopCommand implements Command {
    private MediaPlayer mediaPlayer;

    public StopCommand(MediaPlayer mediaPlayer) {
        this.mediaPlayer = mediaPlayer;
    }

    @Override
    public void execute() {
        mediaPlayer.stop();
    }
}

class EditCommand implements Command {
    private MediaPlayer mediaPlayer;

    public EditCommand(MediaPlayer mediaPlayer) {
        this.mediaPlayer = mediaPlayer;
    }

    @Override
    public void execute() {
        mediaPlayer.editMedia();
    }
}

// Invoker
class MediaControl {
    private Command playCommand;
    private Command pauseCommand;
    private Command stopCommand;
    private Command editCommand;
    private PlayerState currentState;

    public void setPlayCommand(Command playCommand) {
        this.playCommand = playCommand;
    }

    public void setPauseCommand(Command pauseCommand) {
        this.pauseCommand = pauseCommand;
    }

    public void setStopCommand(Command stopCommand) {
        this.stopCommand = stopCommand;
    }

    public void setEditCommand(Command editCommand) {
        this.editCommand = editCommand;
    }

    public void setCurrentState(PlayerState state) {
        this.currentState = state;
    }

    public void play() {
        playCommand.execute();
    }

    public void pause() {
        pauseCommand.execute();
    }

    public void stop() {
        stopCommand.execute();
    }

    public void edit() {
        editCommand.execute();
    }
}

// Client code
 class MediaApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        MediaPlayer mediaPlayer = new AudioPlayer();
        MediaControl control = new MediaControl();
        boolean isRunning = true;
        String mediaFile = null;

        while (isRunning) {
            System.out.println("Menu:");
            System.out.println("1. Enter Media File");
            System.out.println("2. Play");
            System.out.println("3. Pause");
            System.out.println("4. Stop");
            System.out.println("5. Edit");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter a media file: ");
                    scanner.nextLine(); // Consume the newline character
                    mediaFile = scanner.nextLine();
                    mediaPlayer.openMedia(mediaFile);

                    // Set commands for the control after opening the media file
                    control.setPlayCommand(new PlayCommand(mediaPlayer));
                    control.setPauseCommand(new PauseCommand(mediaPlayer));
                    control.setStopCommand(new StopCommand(mediaPlayer));
                    control.setEditCommand(new EditCommand(mediaPlayer));
                    break;
                case 2:
                    control.play();
                    break;
                case 3:
                    control.pause();
                    break;
                case 4:
                    control.stop();
                    break;
                case 5:
                    control.edit();
                    break;
                case 6:
                    System.out.println("Exiting...");
                    isRunning = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}


