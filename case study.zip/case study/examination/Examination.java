import java.util.*;
import java.util.function.Supplier;

abstract class Question {
    private String question;
    private List<String> options;
    private int correctOption;

    public Question(String question, List<String> options, int correctOption) {
        this.question = question;
        this.options = options;
        this.correctOption = correctOption;
    }

    public String getQuestion() {
        return question;
    }

    public List<String> getOptions() {
        return options;
    }

    public int getCorrectOption() {
        return correctOption;
    }

    public abstract int evaluate(List<Integer> userAnswers);
}

class MultipleChoiceQuestion extends Question {
    public MultipleChoiceQuestion(String question, List<String> options, int correctOption) {
        super(question, options, correctOption);
    }

    @Override
    public int evaluate(List<Integer> userAnswers) {
        if (userAnswers.size() != 1) {
            return 0; // Only one answer is allowed for a multiple-choice question
        }
        return userAnswers.get(0) == getCorrectOption() ? 1 : 0;
    
}
}

class QuestionFactory {
    public static Question createQuestion(String questionType, String question, List<String> options, int correctOption) {
        switch (questionType) {
            case "MCQ":
                return new MultipleChoiceQuestion(question, options, correctOption);
            default:
                throw new IllegalArgumentException("Invalid question type");
        }
    }
}

public class Examination {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Examination System!");
        System.out.print("Enter your name: ");
        String studentName = scanner.nextLine();

        System.out.println("Choose your stream:");
        System.out.println("1. Computer Science");
        System.out.println("2. Mathematics");
        System.out.println("3. Electronics");
        System.out.print("Enter the stream number: ");
        int selectedStream = scanner.nextInt();
        scanner.nextLine(); 
        
         List<Question> questions = new ArrayList<>();

         switch (selectedStream) {
            case 1:
                questions.add(QuestionFactory.createQuestion("MCQ", "What is a CPU?", Arrays.asList("Central Processing Unit", "Centralized Processing Unit", "Control Processing Unit"), 0));
                questions.add(QuestionFactory.createQuestion("MCQ", "What is a compiler?", Arrays.asList("A software that translates source code to machine code", "A hardware component in a computer", "An input device"), 0));
                break;
            case 2:
                questions.add(QuestionFactory.createQuestion("MCQ", "What is 2 + 2?", Arrays.asList("3", "4", "5"), 1));
                questions.add(QuestionFactory.createQuestion("MCQ", "What is 7 * 8?", Arrays.asList("45", "64", "56"), 2));
                break;
            case 3:
                questions.add(QuestionFactory.createQuestion("MCQ", "What is a diode?", Arrays.asList("A semiconductor device with two terminals", "A type of resistor", "A type of battery"), 0));
                questions.add(QuestionFactory.createQuestion("MCQ", "What is Ohm's Law?", Arrays.asList("V = IR", "F = ma", "E = mc^2"), 0));
                break;
            default:
                System.out.println("Invalid stream selection.");
                return;
        }

        int totalScore = 0;

        for (int i = 0; i < questions.size(); i++) {
            Question currentQuestion = questions.get(i);
            System.out.println("Question " + (i + 1) + ": " + currentQuestion.getQuestion());
            List<String> options = currentQuestion.getOptions();
            for (int j = 0; j < options.size(); j++) {
                System.out.println((j + 1) + ". " + options.get(j));
            }

            System.out.print("Enter your answer (1-" + options.size() + "): ");
            int userAnswer = scanner.nextInt();
            List<Integer> userAnswers = Collections.singletonList(userAnswer - 1);

            int scoreForQuestion = currentQuestion.evaluate(userAnswers);
            totalScore += scoreForQuestion;

            System.out.println("Your score for this question: " + scoreForQuestion);
        }

        System.out.println("Thanks for taking the examination, " + studentName + "!");
        System.out.println("Total score: " + totalScore);
    }
}
